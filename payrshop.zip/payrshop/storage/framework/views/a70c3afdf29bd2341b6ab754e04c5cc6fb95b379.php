<?php $__env->startSection('main'); ?>
    <div class="prc-col-md-10 prc-middlecol"  >
    <div class="d-flex text-center" style="height:90%; flex-direction: column;flex-wrap: nowrap; justify-content: center; align-items: center; align-content: center;">
        <h4>Category Not Found</h4>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wonder\payrshop\resources\views/store/category/404.blade.php ENDPATH**/ ?>