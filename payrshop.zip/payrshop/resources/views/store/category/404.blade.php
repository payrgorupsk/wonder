@extends('layouts.app')
@section('main')
    <div class="prc-col-md-10 prc-middlecol"  >
    <div class="d-flex text-center" style="height:90%; flex-direction: column;flex-wrap: nowrap; justify-content: center; align-items: center; align-content: center;">
        <h4>Category Not Found</h4>
    </div>
</div>
@endsection

